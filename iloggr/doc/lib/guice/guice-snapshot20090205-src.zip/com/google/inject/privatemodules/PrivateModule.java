// Copyright 2008 Google Inc. All Rights Reserved.

package com.google.inject.privatemodules;

/**
 * @deprecated the private module class has moved. Prefer {@code com.google.inject.PrivateModule}.
 *
 * @author jessewilson
 */
@Deprecated
public abstract class PrivateModule extends com.google.inject.PrivateModule {}
